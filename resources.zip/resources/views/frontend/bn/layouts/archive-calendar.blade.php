<div class="greybg-area calender-section margin-top-25 margin-bottom-25">
    <div class="section-hedding">
        <h2>আর্কাইভ <span></span></h2>
    </div>
    <div class='design'>
        <div id="datepicker"></div>
    </div>
</div>