<div class="marginBottom20">
    <div class="">
        <div class="inauguration">
            <a href="https://www.dhakaprokash24.com/topic/পদ্মা-সেতু" target="_blank">
                <img src="{{ asset('media/advertisement/2022June/Count-Down_Padma.png') }}" style="width:100%;" alt="Padma bridge inauguration - 25 june, 2022" class="img-responsive">
                <div id="countdown" class="img-responsive" style="display: none">
                    <span><i class="remaining">স্বপ্নপূরণের  আর মাত্র</i><br></span>
                    <span class="days time"><strong id="timerDay"></strong> <br><i class="padma-day">দিন</i></span>
                    <span class="hours time"><strong id="timerHour"></strong> <br><i class="padma-day">ঘণ্টা</i></span>
                    <span class="minutes time"><strong id="timerMinute"></strong> <br><i class="padma-day">মিনিট</i></span>
                    <span class="seconds time"><strong id="timerSecond"></strong> <br><i class="padma-day"> সেকেন্ড</i></span>
                </div>
            </a>
        </div>
    </div>

{{--    <div class="hidden-md hidden-lg">--}}
{{--        <div class="inauguration">--}}
{{--            <a href="https://www.jagonews24.com/topic/%E0%A6%AA%E0%A6%A6%E0%A7%8D%E0%A6%AE%E0%A6%BE-%E0%A6%B8%E0%A7%87%E0%A6%A4%E0%A7%81" target="_blank">--}}
{{--                <img src="{{ asset('media/advertisement/2022June/Count-Down_Padma.png') }}" style="width:100%;" alt="Padma bridge inauguration - 25 june, 2022" class="img-responsive">--}}
{{--                <div id="countdown">--}}
{{--                    <span><i class="remaining">স্বপ্নপূরণের  আর মাত্র</i><br> </span>--}}
{{--                    <span class="days time"> <br> <i class="padma-day">দিন</i> </span>--}}
{{--                    <span class="hours time"> <br><i class="padma-day">ঘণ্টা</i>  </span>--}}
{{--                    <span class="minutes time"> <br><i class="padma-day">মিনিট</i>  </span>--}}
{{--                    <span class="seconds time"> <br><i class="padma-day"> সেকেন্ড</i></span>--}}
{{--                </div>--}}
{{--            </a>--}}
{{--        </div>--}}
{{--    </div>--}}
</div>
